using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Game_Ui_Contollor : MonoBehaviour
{
    public GameObject Menu;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.Escape))
        {
            Menu.SetActive(true);
        }
    }
}
