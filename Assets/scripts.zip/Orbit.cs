using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Orbit : MonoBehaviour
{
    // Start is called before the first frame update
    public Transform target;
    public float orbitSpeed;
    Vector3 offSet;
    
    void Start()
    {
        offSet = transform.position - target.position;
    }

    // Update is called once per frame
    void Update()
    {

        if (target == true)
        {
            transform.position = target.position + offSet;
            transform.RotateAround(target.position,
                                    Vector3.up,
                                    orbitSpeed * Time.deltaTime);
            offSet = transform.position - target.position;
        }
        else if (target == false) return;
    }
}
